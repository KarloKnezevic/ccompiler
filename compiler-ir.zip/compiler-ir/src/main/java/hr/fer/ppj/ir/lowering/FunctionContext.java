package hr.fer.ppj.ir.lowering;

import hr.fer.ppj.ir.build.IrFunctionBuilder;
import hr.fer.ppj.ir.types.IrType;
import hr.fer.ppj.ir.util.AddressReuseContext;
import hr.fer.ppj.ir.util.BlockLocalSymbolAddressCache;
import hr.fer.ppj.ir.util.VariableNameManager;
import hr.fer.ppj.semantics.symbols.SymbolTable;
import java.util.Objects;

/**
 * Manages function-level context during IR generation.
 *
 * <p>This context tracks:
 * <ul>
 *   <li>Current function builder</li>
 *   <li>Function scope (symbol table)</li>
 *   <li>Return type (for type promotion)</li>
 *   <li>Local offset for slot allocation</li>
 *   <li>Logical result counter</li>
 *   <li>Variable name manager (for shadowing)</li>
 *   <li>Address reuse context (for optimizations)</li>
 * </ul>
 *
 * @author <a href="https://karloknezevic.github.io/">Karlo Knežević</a>
 */
public final class FunctionContext {

  private final IrFunctionBuilder functionBuilder;
  private final SymbolTable functionScope;
  private final IrType returnType;
  private final VariableNameManager variableNameManager;
  private final AddressReuseContext addressReuseContext;
  private final BlockLocalSymbolAddressCache blockLocalAddressCache;
  private int localOffset;
  private int logicalResultCounter;
  private LoopContext loopContext;
  private String nextExpressionMergeLabel;
  private hr.fer.ppj.ir.model.IrTemp deferredPostfixIncrementValue;
  private hr.fer.ppj.ir.model.IrTemp deferredPostfixIncrementAddr;
  private String deferredPostfixIncrementVarName;

  public FunctionContext(
      IrFunctionBuilder functionBuilder,
      SymbolTable functionScope,
      IrType returnType) {
    this.functionBuilder = Objects.requireNonNull(functionBuilder, "functionBuilder must not be null");
    this.functionScope = Objects.requireNonNull(functionScope, "functionScope must not be null");
    this.returnType = returnType; // Can be null for void functions
    this.variableNameManager = new VariableNameManager();
    this.addressReuseContext = new AddressReuseContext();
    this.blockLocalAddressCache = new BlockLocalSymbolAddressCache();
    this.localOffset = 0;
    this.logicalResultCounter = 0;
    this.loopContext = LoopContext.empty();
  }

  public IrFunctionBuilder functionBuilder() {
    return functionBuilder;
  }

  public SymbolTable functionScope() {
    return functionScope;
  }

  public IrType returnType() {
    return returnType;
  }

  public int localOffset() {
    return localOffset;
  }

  public void setLocalOffset(int localOffset) {
    this.localOffset = localOffset;
  }

  public int logicalResultCounter() {
    return logicalResultCounter;
  }

  public void setLogicalResultCounter(int logicalResultCounter) {
    this.logicalResultCounter = logicalResultCounter;
  }

  public int incrementLogicalResultCounter() {
    return logicalResultCounter++;
  }

  public VariableNameManager variableNameManager() {
    return variableNameManager;
  }

  public AddressReuseContext addressReuseContext() {
    return addressReuseContext;
  }

  public BlockLocalSymbolAddressCache blockLocalAddressCache() {
    return blockLocalAddressCache;
  }

  /**
   * Called when a new basic block starts.
   *
   * <p>This clears block-local caches to ensure addresses are only reused within the same block.
   *
   * @param label the label of the new block
   */
  public void onNewBlock(String label) {
    blockLocalAddressCache.clearForNewBlock();
    // Also clear statement-local caches when starting a new block
    addressReuseContext.beginStatement();
  }

  public LoopContext loopContext() {
    return loopContext;
  }

  public void setLoopContext(LoopContext loopContext) {
    this.loopContext = loopContext != null ? loopContext : LoopContext.empty();
  }

  /**
   * Gets the next expression merge label (for chaining expression statements).
   * Returns null if not set.
   */
  public String nextExpressionMergeLabel() {
    return nextExpressionMergeLabel;
  }

  /**
   * Sets the next expression merge label (for chaining expression statements).
   */
  public void setNextExpressionMergeLabel(String label) {
    this.nextExpressionMergeLabel = label;
  }

  /**
   * Stores the value and address loaded for a deferred postfix increment.
   * Used in binary expressions like x + y++ where we load y, add, then increment.
   */
  public void setDeferredPostfixIncrementValue(String varName, hr.fer.ppj.ir.model.IrTemp value, hr.fer.ppj.ir.model.IrTemp addr) {
    this.deferredPostfixIncrementVarName = varName;
    this.deferredPostfixIncrementValue = value;
    this.deferredPostfixIncrementAddr = addr;
  }

  /**
   * Gets the deferred postfix increment value if it matches the variable name.
   */
  public hr.fer.ppj.ir.model.IrTemp getDeferredPostfixIncrementValue(String varName) {
    if (deferredPostfixIncrementVarName != null && deferredPostfixIncrementVarName.equals(varName)) {
      return deferredPostfixIncrementValue;
    }
    return null;
  }

  /**
   * Gets the deferred postfix increment address if it matches the variable name.
   */
  public hr.fer.ppj.ir.model.IrTemp getDeferredPostfixIncrementAddr(String varName) {
    if (deferredPostfixIncrementVarName != null && deferredPostfixIncrementVarName.equals(varName)) {
      return deferredPostfixIncrementAddr;
    }
    return null;
  }

  /**
   * Clears the deferred postfix increment value and address.
   */
  public void clearDeferredPostfixIncrementValue() {
    this.deferredPostfixIncrementVarName = null;
    this.deferredPostfixIncrementValue = null;
    this.deferredPostfixIncrementAddr = null;
  }
}
