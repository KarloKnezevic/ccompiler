package hr.fer.ppj.ir.lowering.stmt;

import hr.fer.ppj.ir.build.IrFunctionBuilder;
import hr.fer.ppj.ir.lowering.ExpressionGenerator;
import hr.fer.ppj.ir.lowering.FunctionContext;
import hr.fer.ppj.ir.lowering.StatementGenerator;
import hr.fer.ppj.ir.model.IrTerminator;
import hr.fer.ppj.semantics.tree.NonTerminalNode;
import hr.fer.ppj.semantics.tree.ParseNode;
import hr.fer.ppj.semantics.tree.TerminalNode;
import hr.fer.ppj.semantics.types.Type;
import hr.fer.ppj.semantics.util.NodeUtils;
import java.util.List;
import java.util.Objects;

/**
 * Generates IR for if/else statements.
 *
 * @author <a href="https://karloknezevic.github.io/">Karlo Knežević</a>
 */
public final class IfStatementGenerator {

  private final ExpressionGenerator expressionGenerator;
  private final LogicalConditionLowerer logicalConditionLowerer;
  private final StatementGenerator statementGenerator;

  public IfStatementGenerator(
      ExpressionGenerator expressionGenerator, StatementGenerator statementGenerator) {
    this.expressionGenerator =
        Objects.requireNonNull(expressionGenerator, "expressionGenerator must not be null");
    this.statementGenerator =
        Objects.requireNonNull(statementGenerator, "statementGenerator must not be null");
    this.logicalConditionLowerer = new LogicalConditionLowerer(expressionGenerator);
  }

  /**
   * Generates an if statement with canonical CFG: thenLabel, elseLabel, afterLabel.
   */
  public void generateIfStatement(
      NonTerminalNode node, FunctionContext functionContext) {
    List<ParseNode> children = node.children();
    if (children.size() < 4) {
      return;
    }

    IrFunctionBuilder builder = functionContext.functionBuilder();

    NonTerminalNode conditionNode = findConditionNode(children);
    if (conditionNode == null) {
      return;
    }

    // Check if there's an else clause
    boolean hasElse = false;
    for (ParseNode child : children) {
      if (child instanceof TerminalNode term && term.symbol().equals("KR_ELSE")) {
        hasElse = true;
        break;
      }
    }

    // Generate canonical labels: thenLabel, elseLabel
    String thenLabel = builder.labelFactory().newLabel();
    String elseLabel = builder.labelFactory().newLabel();

    // Emit branch using LogicalConditionLowerer (handles logical expressions with short-circuit)
    logicalConditionLowerer.emitConditionAsBranch(conditionNode, functionContext, thenLabel, elseLabel);

    // Generate THEN branch
    builder.startBlock(thenLabel);
    generateThenBranch(children, functionContext);
    boolean thenTerminated = currentBlockHasTerminator(builder);
    
    // Create afterLabel if then branch doesn't terminate (we'll need it for the join)
    // Create it before starting elseLabel to get correct label ordering
    String afterLabel = null;
    if (!thenTerminated) {
      afterLabel = builder.labelFactory().newLabel();
      builder.setTerminator(new IrTerminator.IrJmpTerm(afterLabel));
    }
    
    // Generate ELSE branch
    builder.startBlock(elseLabel);
    boolean elseTerminated = false;
    if (hasElse) {
      generateElseBranch(children, functionContext);
      elseTerminated = currentBlockHasTerminator(builder);
      if (!elseTerminated) {
        // Else branch doesn't terminate - need afterLabel
        if (afterLabel == null) {
          afterLabel = builder.labelFactory().newLabel();
        }
        builder.setTerminator(new IrTerminator.IrJmpTerm(afterLabel));
      }
    } else {
      // No else clause
      if (thenTerminated) {
        // Then branch terminated - else label continues execution (no jump, no afterLabel)
      } else {
        // Then branch falls through - else should jump to join
        if (afterLabel == null) {
          afterLabel = builder.labelFactory().newLabel();
        }
        builder.setTerminator(new IrTerminator.IrJmpTerm(afterLabel));
      }
    }
    
    // Start afterLabel block if it was created
    if (afterLabel != null) {
      builder.startBlock(afterLabel);
    }
  }

  /**
   * Checks if the current block has a terminator.
   * Returns true if the current block has been terminated (getCurrentBlockLabel() returns null).
   */
  private boolean currentBlockHasTerminator(IrFunctionBuilder builder) {
    return builder.getCurrentBlockLabel() == null;
  }

  private NonTerminalNode findConditionNode(List<ParseNode> children) {
    // Find the condition expression node
    for (ParseNode child : children) {
      if (child instanceof NonTerminalNode nt) {
        String symbol = nt.symbol();
        // Look for expression nodes that can be conditions
        if (symbol.equals("<izraz>")
            || symbol.equals("<jednakosni_izraz>")
            || symbol.equals("<odnosni_izraz>")
            || symbol.equals("<log_i_izraz>")
            || symbol.equals("<log_ili_izraz>")) {
          return nt;
        }
      }
    }
    return null;
  }




  private void generateThenBranch(
      List<ParseNode> children, FunctionContext functionContext) {
    boolean foundDZagrada = false;
    for (ParseNode child : children) {
      if (child instanceof TerminalNode term && term.symbol().equals("D_ZAGRADA")) {
        foundDZagrada = true;
        continue;
      }
      if (foundDZagrada && child instanceof NonTerminalNode nt && nt.symbol().equals("<naredba>")) {
        if (nt.children().size() > 0) {
          ParseNode firstChild = nt.children().get(0);
          if (firstChild instanceof NonTerminalNode firstNt
              && firstNt.symbol().equals("<slozena_naredba>")) {
            statementGenerator.generateCompoundStatement(firstNt, functionContext, false);
          } else {
            statementGenerator.generateStatement(nt, functionContext);
          }
        } else {
          statementGenerator.generateStatement(nt, functionContext);
        }
        break;
      }
      if (foundDZagrada && child instanceof TerminalNode term && term.symbol().equals("KR_ELSE")) {
        break;
      }
    }
  }

  private void generateElseBranch(
      List<ParseNode> children, FunctionContext functionContext) {
    boolean hasElse = false;
    for (ParseNode child : children) {
      if (child instanceof TerminalNode term && term.symbol().equals("KR_ELSE")) {
        hasElse = true;
        int elseIndex = children.indexOf(child);
        if (elseIndex + 1 < children.size()) {
          ParseNode elseStmt = children.get(elseIndex + 1);
          if (elseStmt instanceof NonTerminalNode nt && nt.symbol().equals("<naredba>")) {
            if (nt.children().size() > 0) {
              ParseNode firstChild = nt.children().get(0);
              if (firstChild instanceof NonTerminalNode firstNt
                  && firstNt.symbol().equals("<slozena_naredba>")) {
                statementGenerator.generateCompoundStatement(firstNt, functionContext, false);
              } else {
                statementGenerator.generateStatement(nt, functionContext);
              }
            } else {
              statementGenerator.generateStatement(nt, functionContext);
            }
          }
        }
        break;
      }
    }
  }
}
